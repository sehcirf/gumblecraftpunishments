<title>Web Advanced Ban</title>
	<meta charset="utf-8">
	<link rel="icon" type="image/png" sizes="16x16" href="img/icon.png">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<!-- BOOTSTRAP -->
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<!-- Meu CSS-->
		<link rel="stylesheet" type="text/css" href="css/style.css">
	<!-- CSS ICON'S -->
	<link href="open-iconic/font/css/open-iconic-bootstrap.min.css" type="text/css" rel="stylesheet">