<!-- 
	MENU - 03.06.2018 
 -->
		<div class="col-md-2">
			<div class="card">
				<div class="card-header bg-dark">
					<div class="menu">
						MENU
					</div>
				</div><!-- ./card-header  -->
				<div class="card-body">
					<button class="btn btn-dark btn-block" onclick="location.href='index.php'"><span class="oi oi-home"></span> Home&nbsp&nbsp&nbsp&nbsp&nbsp
					</button>
					<button class="btn btn-dark btn-block" onclick="location.href='history.php'"><span class="oi oi-clipboard"></span> <?php echo BTN_HISTORIC ?></button>
				</div><!-- ./card-body -->
			</div>
		</div>