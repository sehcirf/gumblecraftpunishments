<!-- 
		FOOTER 01.05.18;
 -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.3/umd/popper.min.js" integrity="sha384-vFJXuSJphROIrBnz7yo7oB41mKfc8JzQZiCq4NCceLEaO4IHwicKwpJf9c9IpFgh" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/js/bootstrap.min.js" integrity="sha384-alpBpkh1PFOepccYVYDB4do5UnbKysX5WZXm3XxPqe5iKTfUKjNkCk9SaVuEZflJ" crossorigin="anonymous"></script>
<script type="text/javascript">
	$(function () {
		$('[data-toggle="tooltip"]').tooltip()
	})
</script>
<script type="text/javascript">
	$(function () {
	  $('[data-toggle="popover"]').popover()
	})
</script>
<footer class="footer">
	<div class="container">
    	<div class="col-md-6 offset-md-3 mt-5">
    		<!-- <hr> -->
    		<small class="d-block text-center">GNU General Public License v3.0<br><a href="https://github.com/luiseduardosilva/webAdvancedBan">WebAdvancedBan</a> Version 1.2.4</small>
    		<small class="d-block text-center">Desenvolvido por<br><a href="http://github.com/luiseduardosilva/">@LuisSilva</a></small>
			</div>
	</div>
</footer>